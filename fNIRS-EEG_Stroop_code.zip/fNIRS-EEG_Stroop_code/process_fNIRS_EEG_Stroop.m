%  This code is used to preprocess the fNIRS raw data in '.tdms' format.
% Written by Zemeng Chen and Chenyang Gao.

clear
clc

% Load the raw fNIRS data.
file_name='S1.tdms';             % Change the file_name to load fNIRS raw data of different participants.
test=TDMS_readTDMSFile(file_name);              % In order to load the .tdms format file, please add the "Matlab_read_tdms_file" folder to path before loading.
yy=test.data;

% Channel extraction.
CHANNEL=20;
column=CHANNEL*2+2;             % 20-channel of Hb, 20channel of HbO and 2-channel of Marker
m=zeros(length(yy{1,3}),column);
for i=1:column
    c=yy{1,i+2};
    m(:,i)=c';
end
m=m(100:end-10,:);
marker=m(:,1);
md=find(marker>2.5);
ucc=find(diff(md)>3000&diff(md)<8000);
ind_marker=[md(ucc)];
data_od=m(:,2:41);
time_points=size(data_od,1);

% Median filter.
data_od=medfilt2(data_od,[50,1]); 

% Calculate baseline.
OD_res=zeros(time_points,40);
Base=mean(data_od(ind_marker(2)-30:ind_marker(2)-20,:));
for ch=1:40
    ca=data_od(:,ch)./Base(ch);
    OD_res(:,ch)=-log10(ca);
end

% Band-pass filter.
OD_f=eegfilt(OD_res',100,0.015,0.2,time_points,50)'; 

% Modified Beer-Lambert Law.
HbO2=zeros(time_points,CHANNEL);  
Hb=zeros(time_points,CHANNEL);   
for ch_n=1:CHANNEL 
    k=ch_n*2;
    HbO2(:,k/2)=1.156*OD_f(:,k)-0.79*OD_f(:,k-1);    
    Hb(:,k/2)=-0.891*OD_f(:,k)+1.165*OD_f(:,k-1);
end

% Extract HbO and Hb epochs for neutral and incongruent stimus.
% 3711 is the number of data points, corresponding to 0.11s before one block,
% 32s (16 trails, each trial continued 2s), and 5s after the block.
% And the sampling rate is 100 Hz.
HbO_epochs=zeros(6,3711,CHANNEL);
Hb_epochs=zeros(6,3711,CHANNEL);
for epoch=1:4
    ind_epoch=ind_marker(epoch)-10:ind_marker(epoch)+3700;
    basement=ind_marker(epoch)-10:ind_marker(epoch);    
    HbO_epochs(epoch,:,:)=HbO2(ind_epoch,:)-mean(HbO2(basement,:));
    Hb_epochs(epoch,:,:)=Hb(ind_epoch,:)-mean(Hb(basement,:));
end